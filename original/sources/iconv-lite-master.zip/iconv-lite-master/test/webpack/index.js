
// Reexport iconv-lite for tests.
exports.iconv = require('iconv-lite');